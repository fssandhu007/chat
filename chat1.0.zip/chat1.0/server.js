const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const cors = require('cors');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: {
    origin: "http://localhost:3000",
    methods: ["GET", "POST"]
  }
});

app.use(cors());

// Store messages in memory (replace with a database in production)
const messages = [];

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Send existing messages to newly connected users
  socket.emit('messages', messages);

  socket.on('sendMessage', (messageData) => {
    const message = {
      id: Date.now().toString(),
      ...messageData,
      status: 'sent'
    };

    messages.push(message);
    io.emit('newMessage', message);

    // Simulate message delivery status updates
    setTimeout(() => {
      message.status = 'delivered';
      io.emit('messageStatusUpdate', message);
    }, 1000);

    setTimeout(() => {
      message.status = 'read';
      io.emit('messageStatusUpdate', message);
    }, 2000);
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

const PORT = process.env.PORT || 5000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});

