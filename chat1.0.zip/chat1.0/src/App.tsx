import React, { useState } from 'react';
import Sidebar from './components/Sidebar';
import ChatWindow from './components/ChatWindow';
import SettingsModal from './components/SettingsModal';

const App: React.FC = () => {
  const [selectedContact, setSelectedContact] = useState<string | null>(null);
  const [isSettingsOpen, setIsSettingsOpen] = useState<boolean>(false);
  const [isDarkMode, setIsDarkMode] = useState<boolean>(false);
  const [textSize, setTextSize] = useState<'small' | 'large'>('small');

  return (
    <div className={`flex h-screen ${isDarkMode ? 'dark' : ''}`}>
      <Sidebar
        onSelectContact={setSelectedContact}
        onOpenSettings={() => setIsSettingsOpen(true)}
      />
      <ChatWindow
        selectedContact={selectedContact}
        textSize={textSize}
      />
      {isSettingsOpen && (
        <SettingsModal
          onClose={() => setIsSettingsOpen(false)}
          isDarkMode={isDarkMode}
          setIsDarkMode={setIsDarkMode}
          textSize={textSize}
          setTextSize={setTextSize}
        />
      )}
    </div>
  );
};

export default App;

