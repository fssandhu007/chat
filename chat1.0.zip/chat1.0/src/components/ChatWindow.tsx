import React, { useState, useEffect } from 'react';
import { Send, Phone, Video, MoreVertical } from 'lucide-react';
import ProfileModal from './ProfileModal';
import { socket } from '../utils/socket';

interface Message {
  id: string;
  text: string;
  sender: 'user' | 'friend';
  status: 'sent' | 'delivered' | 'read';
  timestamp: string;
}

interface ChatWindowProps {
  selectedContact: string | null;
  textSize: 'small' | 'large';
}

const ChatWindow: React.FC<ChatWindowProps> = ({ selectedContact, textSize }) => {
  const [messages, setMessages] = useState<Message[]>([]);
  const [newMessage, setNewMessage] = useState<string>('');
  const [isProfileOpen, setIsProfileOpen] = useState<boolean>(false);

  useEffect(() => {
    // Listen for incoming messages
    socket.on('newMessage', (message: Message) => {
      setMessages(prev => [...prev, message]);
    });

    // Listen for message status updates
    socket.on('messageStatusUpdate', (updatedMessage: Message) => {
      setMessages(prev =>
        prev.map(msg =>
          msg.id === updatedMessage.id ? updatedMessage : msg
        )
      );
    });

    // Cleanup listeners on unmount
    return () => {
      socket.off('newMessage');
      socket.off('messageStatusUpdate');
    };
  }, []);

  if (!selectedContact) {
    return (
      <div className="flex-grow bg-gray-200 dark:bg-gray-900 flex items-center justify-center">
        <img src="/dostluk-logo.png" alt="Dostluk Logo" className="w-32 h-32" />
      </div>
    );
  }

  const handleSendMessage = () => {
    if (newMessage.trim()) {
      const message: Omit<Message, 'id' | 'status'> = {
        text: newMessage,
        sender: 'user',
        timestamp: new Date().toLocaleTimeString([], { 
          hour: '2-digit', 
          minute: '2-digit' 
        })
      };

      // Emit the message to the server
      socket.emit('sendMessage', message);
      setNewMessage('');
    }
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    handleSendMessage();
  };

  const handleProfileClick = () => {
    setIsProfileOpen(true);
  };

  return (
    <div className="flex-grow flex flex-col bg-gray-200 dark:bg-gray-900">
      <div className="bg-white dark:bg-gray-800 p-4 flex justify-between items-center">
        <div 
          className="flex items-center cursor-pointer"
          onClick={handleProfileClick}
        >
          <div className="w-10 h-10 bg-gray-300 dark:bg-gray-600 rounded-full mr-3"></div>
          <span className="font-semibold dark:text-white">Friend's Name</span>
        </div>
        <div className="flex space-x-4">
          <Phone className="text-gray-600 dark:text-gray-300 cursor-pointer" size={24} />
          <Video className="text-gray-600 dark:text-gray-300 cursor-pointer" size={24} />
          <MoreVertical className="text-gray-600 dark:text-gray-300 cursor-pointer" size={24} />
        </div>
      </div>
      <div className="flex-grow overflow-y-auto p-4 space-y-4">
        {messages.map(message => (
          <div
            key={message.id}
            className={`flex ${message.sender === 'user' ? 'justify-end' : 'justify-start'}`}
          >
            <div
              className={`max-w-xs p-3 rounded-lg ${
                message.sender === 'user'
                  ? 'bg-blue-500 text-white'
                  : 'bg-gray-300 dark:bg-gray-700 dark:text-white'
              } ${textSize === 'large' ? 'text-lg' : 'text-base'}`}
            >
              {message.text}
              <div className="text-xs mt-1 text-gray-200 dark:text-gray-400">
                {message.timestamp}
              </div>
            </div>
          </div>
        ))}
      </div>
      <form onSubmit={handleSubmit} className="bg-white dark:bg-gray-800 p-4 flex items-center">
        <input
          type="text"
          placeholder="Type a message..."
          className="flex-grow p-2 rounded-l-md bg-gray-100 dark:bg-gray-700 dark:text-white"
          value={newMessage}
          onChange={(e) => setNewMessage(e.target.value)}
        />
        <button
          type="submit"
          className="bg-blue-500 text-white p-2 rounded-r-md"
        >
          <Send size={24} />
        </button>
      </form>

      <ProfileModal 
        isOpen={isProfileOpen}
        onClose={() => setIsProfileOpen(false)}
        contactName="Friend's Name"
      />
    </div>
  );
};

export default ChatWindow;

