import React, { useEffect } from 'react';
import { X, Bell, Search, Lock, ChevronDown, Image, Shield } from 'lucide-react';

interface ProfileModalProps {
  isOpen: boolean;
  onClose: () => void;
  contactName: string;
}

const ProfileModal: React.FC<ProfileModalProps> = ({ isOpen, onClose, contactName }) => {
  useEffect(() => {
    const handleEscape = (e: KeyboardEvent) => {
      if (e.key === 'Escape') {
        onClose();
      }
    };

    if (isOpen) {
      window.addEventListener('keydown', handleEscape);
    }

    return () => {
      window.removeEventListener('keydown', handleEscape);
    };
  }, [isOpen, onClose]);

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-start justify-end">
      <div className="w-96 h-full bg-white dark:bg-gray-800 animate-slide-left">
        {/* Profile Header */}
        <div className="relative pt-8 pb-4">
          <div className="absolute top-4 right-4 z-10">
            <button
              onClick={onClose}
              className="p-2 rounded-full bg-gray-200 hover:bg-gray-300 dark:bg-gray-700 dark:hover:bg-gray-600 text-gray-600 dark:text-gray-300"
            >
              <X size={20} />
            </button>
          </div>
          <div className="flex flex-col items-center">
            <div className="relative mb-4">
              <img
                src="/placeholder.svg?height=120&width=120"
                alt={contactName}
                className="w-32 h-32 rounded-full"
              />
              <div className="absolute bottom-2 right-2 w-4 h-4 bg-green-500 rounded-full border-2 border-white dark:border-gray-800"></div>
            </div>
          </div>
        </div>

        {/* Profile Content */}
        <div className="px-4 pb-4">
          <h2 className="text-2xl font-bold text-center mb-2 dark:text-white">{contactName}</h2>
          <div className="flex justify-center gap-8 mb-6">
            <button className="flex flex-col items-center text-gray-600 dark:text-gray-300">
              <div className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 mb-1">
                <Bell size={20} />
              </div>
              <span className="text-sm">Mute</span>
            </button>
            <button className="flex flex-col items-center text-gray-600 dark:text-gray-300">
              <div className="p-3 rounded-full bg-gray-100 dark:bg-gray-700 mb-1">
                <Search size={20} />
              </div>
              <span className="text-sm">Search</span>
            </button>
          </div>

          {/* Encryption Info */}
          <div className="flex items-center gap-2 p-3 bg-gray-50 dark:bg-gray-700 rounded-lg mb-4">
            <Lock size={16} className="text-gray-600 dark:text-gray-300" />
            <span className="text-sm text-gray-600 dark:text-gray-300">End-to-end encrypted</span>
          </div>

          {/* Collapsible Sections */}
          <div className="space-y-2">
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg">
              <span className="font-medium dark:text-white">Chat info</span>
              <ChevronDown size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg">
              <span className="font-medium dark:text-white">Media & files</span>
              <ChevronDown size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
            <button className="w-full flex items-center justify-between p-3 hover:bg-gray-50 dark:hover:bg-gray-700 rounded-lg">
              <span className="font-medium dark:text-white">Privacy & support</span>
              <ChevronDown size={20} className="text-gray-600 dark:text-gray-300" />
            </button>
          </div>

          {/* Block Button */}
          <button className="w-full mt-6 p-3 text-red-500 font-medium hover:bg-red-50 dark:hover:bg-red-900/20 rounded-lg">
            Block
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProfileModal;

