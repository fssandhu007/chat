import React from 'react';
import { X } from 'lucide-react';

interface SettingsModalProps {
  onClose: () => void;
  isDarkMode: boolean;
  setIsDarkMode: (isDark: boolean) => void;
  textSize: 'small' | 'large';
  setTextSize: (size: 'small' | 'large') => void;
}

const SettingsModal: React.FC<SettingsModalProps> = ({
  onClose,
  isDarkMode,
  setIsDarkMode,
  textSize,
  setTextSize,
}) => {
  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 p-6 rounded-lg w-96">
        <div className="flex justify-between items-center mb-4">
          <h2 className="text-xl font-semibold dark:text-white">Settings</h2>
          <button onClick={onClose}>
            <X className="text-gray-600 dark:text-gray-300" size={24} />
          </button>
        </div>
        <div className="space-y-4">
          <div className="flex items-center justify-between">
            <span className="dark:text-white">Dark Mode</span>
            <label className="switch">
              <input
                type="checkbox"
                checked={isDarkMode}
                onChange={(e) => setIsDarkMode(e.target.checked)}
              />
              <span className="slider round"></span>
            </label>
          </div>
          <div className="flex items-center justify-between">
            <span className="dark:text-white">Text Size</span>
            <select
              value={textSize}
              onChange={(e) => setTextSize(e.target.value as 'small' | 'large')}
              className="p-2 rounded-md bg-gray-100 dark:bg-gray-700 dark:text-white"
            >
              <option value="small">Small</option>
              <option value="large">Large</option>
            </select>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SettingsModal;

