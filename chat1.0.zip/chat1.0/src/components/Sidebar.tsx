import React, { useState } from 'react';
import { Search, Archive, Phone, Settings } from 'lucide-react';

interface Contact {
  id: string;
  name: string;
  lastMessage: string;
  timestamp: string;
  unreadCount?: number;
}

const contacts: Contact[] = [
  { id: '1', name: 'Alice', lastMessage: 'Hey, how are you?', timestamp: '10:30 AM', unreadCount: 2 },
  { id: '2', name: 'Bob', lastMessage: 'See you later!', timestamp: 'Yesterday' },
  { id: '3', name: 'Charlie', lastMessage: 'Thanks for the help!', timestamp: '2 days ago' },
];

interface SidebarProps {
  onSelectContact: (contactId: string) => void;
  onOpenSettings: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ onSelectContact, onOpenSettings }) => {
  const [searchTerm, setSearchTerm] = useState<string>('');

  const filteredContacts = contacts.filter(contact =>
    contact.name.toLowerCase().includes(searchTerm.toLowerCase())
  );

  return (
    <div className="w-1/4 bg-gray-100 dark:bg-gray-800 flex flex-col">
      <div className="p-4">
        <div className="relative">
          <input
            type="text"
            placeholder="Search contacts..."
            className="w-full p-2 pl-10 rounded-md bg-white dark:bg-gray-700 dark:text-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search className="absolute left-3 top-2.5 text-gray-400" size={20} />
        </div>
      </div>
      <div className="flex-grow overflow-y-auto">
        {filteredContacts.map(contact => (
          <div
            key={contact.id}
            className="p-4 hover:bg-gray-200 dark:hover:bg-gray-700 cursor-pointer"
            onClick={() => onSelectContact(contact.id)}
          >
            <div className="flex justify-between items-center">
              <span className="font-semibold dark:text-white">{contact.name}</span>
              <span className="text-sm text-gray-500 dark:text-gray-400">{contact.timestamp}</span>
            </div>
            <div className="text-sm text-gray-600 dark:text-gray-300">{contact.lastMessage}</div>
            {contact.unreadCount && (
              <span className="bg-blue-500 text-white text-xs rounded-full px-2 py-1 mt-1 inline-block">
                {contact.unreadCount}
              </span>
            )}
          </div>
        ))}
      </div>
      <div className="p-4 flex justify-between">
        <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
          <Archive className="text-gray-600 dark:text-gray-300" size={24} />
        </button>
        <button className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700">
          <Phone className="text-gray-600 dark:text-gray-300" size={24} />
        </button>
        <button
          className="p-2 rounded-full hover:bg-gray-200 dark:hover:bg-gray-700"
          onClick={onOpenSettings}
        >
          <Settings className="text-gray-600 dark:text-gray-300" size={24} />
        </button>
      </div>
    </div>
  );
};

export default Sidebar;

